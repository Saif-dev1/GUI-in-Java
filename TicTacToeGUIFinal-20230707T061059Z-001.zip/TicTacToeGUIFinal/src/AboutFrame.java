import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

class AboutFrame extends JFrame implements ActionListener {
    JButton menu;
    public AboutFrame() {

        super("About");
        menu = new JButton("Main Menu");
        menu.addActionListener(this);
        menu.setFocusable(false);
        menu.setOpaque(true);
        menu.setBackground(new Color(231, 194, 52, 255));


        setSize(800, 700);
        setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JLabel headerLabel = new JLabel("Tic Tac Toe");
        headerLabel.setBounds(0, 50, getWidth(), 100);
        headerLabel.setForeground(Color.WHITE);
        headerLabel.setFont(new Font("Arial", Font.BOLD, 32));
        headerLabel.setHorizontalAlignment(SwingConstants.CENTER);
        add(headerLabel);

        AnimatedLabel animatedLabel = new AnimatedLabel("This game is made by Pindari coders");
        animatedLabel.setBounds(200, 200, 400, 100);
        animatedLabel.setForeground(Color.WHITE);
        animatedLabel.setFont(new Font("Arial", Font.PLAIN, 24));
        animatedLabel.setHorizontalAlignment(SwingConstants.CENTER);
        add(animatedLabel);

        JPanel gradientPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
                GradientPaint gradient = new GradientPaint(0, 0, new Color(127, 77, 192), getWidth(), getHeight(), new Color(172, 27, 199));
                g2d.setPaint(gradient);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        gradientPanel.setBounds(0, 0, getWidth(), getHeight());
        gradientPanel.setLayout(new FlowLayout());
        menu.setBounds(100,600,250,100);
        gradientPanel.add(menu);
        add(gradientPanel);

        setResizable(false);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == menu)
        {
            dispose();
            new OpeningFrame();
        }
    }
}


class AnimatedLabel extends JLabel implements Runnable {
    private static final int DELAY = 300; // Delay between animation frames in milliseconds
    private static final String DEFAULT_TEXT = "This game is made by Pindari coders";
    private static final Color[] COLORS = {Color.RED, Color.GREEN, Color.BLUE, Color.YELLOW, Color.ORANGE}; // Array of colors

    private String text;
    private int currentColorIndex;

    public AnimatedLabel(String text) {
        this.text = text;
        this.currentColorIndex = 0;
        setForeground(COLORS[currentColorIndex]);
        setText(text);

        new Thread(this).start();
    }

    @Override
    public void run() {
        while (true) {
            try {
                Thread.sleep(DELAY);
                currentColorIndex = (currentColorIndex + 1) % COLORS.length;
                SwingUtilities.invokeLater(() -> setForeground(COLORS[currentColorIndex]));
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}

